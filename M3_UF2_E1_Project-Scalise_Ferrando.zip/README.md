# M3-UF2-Project
## Proyecto MAIL M3 UF2 1DAM

Software created by Thomas Scalise and Joan S. Ferrando.

Last stable version: 1.0

Date of release: The date remains to be specified.

### Changelog:
***v1.0***
- GUI library almost finished
- Start develop of Main.java
- Add file chooser(multiple files accepted)
- Create a functional login window and mail window

#### TODO - Trello Board:
All the things to do are in the following Trello link:
https://trello.com/b/d1vHHZKZ/m3-uf2-project

#### GitHub Repository: 
https://github.com/KirtashW17/M3-UF2-Project/
